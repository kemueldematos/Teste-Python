import pgzrun
from random import randint
from pygame import Rect

LARGURA = 800
ALTURA = 480

MENU = "menu"
JOGO = "jogo"

estado = MENU
som_ativo = True

music.play("fundo")
music.set_volume(0.5)

mergulhador = Actor("mergulhador_parado1", pos=(100, 380))
mergulhador.vx = 0
mergulhador.vy = 0
mergulhador.no_chao = False
mergulhador.quadro = 0
mergulhador.tempo_anim = 0

plataformas = [Rect((0, 440), (800, 40)), Rect((300, 350), (150, 20)), Rect((600, 250), (150, 20))]

class Inimigo:
    def __init__(self, x, y):
        self.ator = Actor("tubarao1", pos=(x, y))
        self.vx = 1
        self.quadro = 0
        self.tempo_anim = 0
        self.limites = (x - 50, x + 50)

    def atualizar(self):
        self.ator.x += self.vx
        if self.ator.x < self.limites[0] or self.ator.x > self.limites[1]:
            self.vx *= -1
        self.tempo_anim += 1
        if self.tempo_anim >= 10:
            self.quadro = (self.quadro + 1) % 2
            self.ator.image = f"tubarao{self.quadro+1}"
            self.tempo_anim = 0

    def desenhar(self):
        self.ator.draw()

inimigos = [Inimigo(400, 410), Inimigo(650, 220)]

botoes = {
    "iniciar": Rect(300, 150, 200, 50),
    "som": Rect(300, 220, 200, 50),
    "sair": Rect(300, 290, 200, 50)
}

imgs_parado = ["mergulhador_parado1", "mergulhador_parado2"]
imgs_andando = ["mergulhador_andando1", "mergulhador_andando2"]

def update():
    global estado, som_ativo
    if estado == JOGO:
        teclas = keyboard
        mergulhador.vx = 0
        if teclas.left:
            mergulhador.vx = -3
        elif teclas.right:
            mergulhador.vx = 3
        mergulhador.x += mergulhador.vx
        mergulhador.vy += 0.3
        mergulhador.y += mergulhador.vy
        mergulhador.no_chao = False
        for plat in plataformas:
            if Rect(mergulhador.x - 20, mergulhador.y, 40, 40).colliderect(plat) and mergulhador.vy >= 0:
                mergulhador.y = plat.top
                mergulhador.vy = 0
                mergulhador.no_chao = True
        if teclas.space and mergulhador.no_chao:
            mergulhador.vy = -6
            if som_ativo:
                sounds.pulo.play()
        mergulhador.tempo_anim += 1
        if mergulhador.tempo_anim >= 10:
            mergulhador.quadro = (mergulhador.quadro + 1) % 2
            if mergulhador.vx == 0:
                mergulhador.image = imgs_parado[mergulhador.quadro]
            else:
                mergulhador.image = imgs_andando[mergulhador.quadro]
            mergulhador.tempo_anim = 0
        for inimigo in inimigos:
            inimigo.atualizar()
        for inimigo in inimigos:
            if mergulhador.colliderect(inimigo.ator):
                if som_ativo:
                    sounds.dano.play()
                mergulhador.pos = (100, 380)
                mergulhador.vy = 0

def draw():
    screen.clear()
    if estado == MENU:
        screen.draw.text("Bubble Diver", center=(LARGURA//2, 80), fontsize=50, color="white")
        for nome, ret in botoes.items():
            screen.draw.filled_rect(ret, "blue")
            screen.draw.textbox(nome.upper(), ret, color="white")
    elif estado == JOGO:
        screen.fill((0, 50, 100))
        mergulhador.draw()
        for plat in plataformas:
            screen.draw.filled_rect(plat, (100, 255, 100))
        for inimigo in inimigos:
            inimigo.desenhar()

def on_mouse_down(pos):
    global estado, som_ativo
    if estado == MENU:
        if botoes["iniciar"].collidepoint(pos):
            estado = JOGO
        elif botoes["som"].collidepoint(pos):
            som_ativo = not som_ativo
            if som_ativo:
                music.play("fundo")
            else:
                music.stop()
        elif botoes["sair"].collidepoint(pos):
            exit()

pgzrun.go()